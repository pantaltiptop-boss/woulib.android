
-- WOULIB v1.0 — PostgreSQL/Supabase starter schema
-- Currency: HTG. Airport-transfer launch: Ayewopò Antoine-Simon, Okay.
-- Apply in a NEW Supabase project after enabling the required extensions.
-- This is a database foundation, not a live payment/GPS integration.

create extension if not exists pgcrypto;

-- ---------- ENUMS ----------
do $$ begin
  create type public.app_role as enum ('customer','driver','admin');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.driver_review_status as enum ('pending','approved','rejected','suspended');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.vehicle_category as enum ('standard_sedan','comfort_sedan','suv','van_minibus');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.booking_status as enum (
    'awaiting_quote','awaiting_payment','paid_unassigned','assigned',
    'driver_arrived','awaiting_customer_start','in_progress',
    'driver_marked_complete','awaiting_admin_review','completed',
    'cancelled','disputed','refunded'
  );
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.payment_method as enum ('moncash','natcash','card','cash_admin');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.payment_status as enum ('pending','succeeded','failed','refunded','partially_refunded');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.trip_event_type as enum (
    'booking_created','quote_set','payment_confirmed','driver_assigned',
    'driver_arrived','customer_confirmed_start','trip_started',
    'driver_marked_arrived','customer_confirmed_completion',
    'admin_review_opened','admin_payout_approved','cancelled','dispute_opened'
  );
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.ledger_entry_type as enum (
    'customer_payment','business_commission','driver_earning',
    'payment_processing_fee','driver_payout','refund','adjustment'
  );
exception when duplicate_object then null; end $$;

-- ---------- PEOPLE ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role public.app_role not null default 'customer',
  full_name text not null,
  phone text not null,
  preferred_language text not null default 'ht',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint profiles_language_check check (preferred_language in ('ht','fr','en'))
);

create unique index if not exists profiles_phone_unique on public.profiles(phone);

create table if not exists public.driver_profiles (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  date_of_birth date,
  residential_address text not null,
  identity_document_type text check (identity_document_type in ('cin','passport')),
  identity_document_storage_path text,
  identity_document_number_encrypted text,
  license_storage_path text,
  license_number_encrypted text,
  payout_method public.payment_method,
  payout_phone text,
  review_status public.driver_review_status not null default 'pending',
  reviewed_by uuid references public.profiles(id),
  reviewed_at timestamptz,
  rejection_reason text,
  created_at timestamptz not null default now(),
  constraint driver_payout_method_check check (payout_method is null or payout_method in ('moncash','natcash'))
);

create table if not exists public.vehicles (
  id uuid primary key default gen_random_uuid(),
  driver_id uuid not null references public.driver_profiles(user_id) on delete cascade,
  category public.vehicle_category not null,
  make text not null,
  model text not null,
  model_year integer,
  plate_number text not null unique,
  passenger_capacity integer not null,
  luggage_capacity integer not null,
  photo_storage_paths text[] not null default '{}',
  review_status public.driver_review_status not null default 'pending',
  reviewed_by uuid references public.profiles(id),
  reviewed_at timestamptz,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  constraint vehicle_capacity_check check (passenger_capacity between 1 and 20 and luggage_capacity between 0 and 30)
);

create index if not exists vehicles_driver_idx on public.vehicles(driver_id);
create index if not exists vehicles_eligibility_idx on public.vehicles(category, review_status, is_active);

-- ---------- DESTINATIONS & PRICING ----------
create table if not exists public.destinations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  area text,
  address_description text,
  latitude double precision,
  longitude double precision,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  constraint destination_coordinates_check check (
    (latitude is null and longitude is null) or
    (latitude between -90 and 90 and longitude between -180 and 180)
  )
);

create unique index if not exists destinations_active_name_unique
  on public.destinations(lower(name)) where is_active = true;

create table if not exists public.fare_rules (
  id uuid primary key default gen_random_uuid(),
  destination_id uuid not null references public.destinations(id),
  vehicle_category public.vehicle_category not null,
  passenger_min integer not null default 1,
  passenger_max integer not null,
  fare_htg numeric(12,2) not null,
  effective_from timestamptz not null default now(),
  effective_until timestamptz,
  is_active boolean not null default true,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  constraint fare_passenger_range check (passenger_min >= 1 and passenger_max >= passenger_min),
  constraint fare_positive check (fare_htg > 0),
  constraint fare_dates_check check (effective_until is null or effective_until > effective_from)
);

create index if not exists fare_rules_lookup_idx
  on public.fare_rules(destination_id, vehicle_category, is_active, effective_from desc);

-- ---------- BOOKINGS ----------
create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  booking_code text not null unique default ('WL-' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,8))),
  customer_id uuid not null references public.profiles(id),
  airport_name text not null default 'Ayewopò Antoine-Simon',
  airport_area text not null default 'Okay, Ayiti',
  destination_id uuid references public.destinations(id),
  custom_destination text,
  destination_latitude double precision,
  destination_longitude double precision,
  flight_number text,
  arrival_at timestamptz not null,
  adults integer not null default 1,
  children integer not null default 0,
  luggage_count integer not null default 0,
  vehicle_category public.vehicle_category not null,
  quoted_fare_htg numeric(12,2),
  business_commission_htg numeric(12,2),
  driver_share_htg numeric(12,2),
  commission_percent numeric(5,2) not null default 20.00,
  status public.booking_status not null default 'awaiting_quote',
  customer_notes text,
  quote_set_by uuid references public.profiles(id),
  quote_set_at timestamptz,
  paid_at timestamptz,
  assigned_at timestamptz,
  trip_started_at timestamptz,
  driver_marked_complete_at timestamptz,
  customer_confirmed_complete_at timestamptz,
  admin_review_due_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint booking_destination_check check (
    destination_id is not null or nullif(trim(custom_destination),'') is not null
  ),
  constraint booking_passengers_check check (adults >= 1 and children >= 0 and adults + children <= 20),
  constraint booking_luggage_check check (luggage_count >= 0 and luggage_count <= 30),
  constraint booking_fare_check check (
    (quoted_fare_htg is null and business_commission_htg is null and driver_share_htg is null)
    or
    (quoted_fare_htg > 0 and business_commission_htg >= 0 and driver_share_htg >= 0
     and round(business_commission_htg + driver_share_htg,2) = round(quoted_fare_htg,2))
  ),
  constraint booking_commission_check check (commission_percent between 0 and 100),
  constraint booking_coordinates_check check (
    (destination_latitude is null and destination_longitude is null) or
    (destination_latitude between -90 and 90 and destination_longitude between -180 and 180)
  )
);

create index if not exists bookings_customer_idx on public.bookings(customer_id, created_at desc);
create index if not exists bookings_dispatch_idx on public.bookings(status, vehicle_category, arrival_at);
create index if not exists bookings_admin_review_idx on public.bookings(status, admin_review_due_at);

create table if not exists public.booking_assignments (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id) on delete cascade,
  driver_id uuid not null references public.driver_profiles(user_id),
  vehicle_id uuid not null references public.vehicles(id),
  accepted_at timestamptz not null default now(),
  revoked_at timestamptz,
  revoked_by uuid references public.profiles(id),
  revocation_reason text
);

-- Only one current driver assignment per booking.
create unique index if not exists one_active_driver_per_booking
  on public.booking_assignments(booking_id) where revoked_at is null;

create index if not exists assignments_driver_idx
  on public.booking_assignments(driver_id, accepted_at desc);

-- ---------- ROUTE ESTIMATES ----------
create table if not exists public.route_estimates (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id) on delete cascade,
  distance_meters integer not null,
  duration_seconds integer not null,
  provider text not null,
  estimated_at timestamptz not null default now(),
  constraint route_estimate_positive check (distance_meters >= 0 and duration_seconds >= 0)
);

-- ---------- PAYMENTS & INTERNAL ACCOUNTING ----------
create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null unique references public.bookings(id),
  method public.payment_method not null,
  provider_name text,
  provider_reference text unique,
  amount_htg numeric(12,2) not null,
  status public.payment_status not null default 'pending',
  processing_fee_htg numeric(12,2) not null default 0,
  currency text not null default 'HTG',
  paid_at timestamptz,
  created_at timestamptz not null default now(),
  constraint payments_htg_only check (currency = 'HTG'),
  constraint payments_amount_check check (amount_htg > 0 and processing_fee_htg >= 0)
);

create table if not exists public.ledger_entries (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid references public.bookings(id),
  payment_id uuid references public.payments(id),
  entry_type public.ledger_entry_type not null,
  amount_htg numeric(12,2) not null,
  beneficiary_user_id uuid references public.profiles(id),
  memo text,
  created_at timestamptz not null default now(),
  constraint ledger_amount_nonzero check (amount_htg <> 0)
);

create index if not exists ledger_booking_idx on public.ledger_entries(booking_id, created_at);
create index if not exists ledger_beneficiary_idx on public.ledger_entries(beneficiary_user_id, created_at desc);

create table if not exists public.driver_payouts (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id),
  driver_id uuid not null references public.driver_profiles(user_id),
  amount_htg numeric(12,2) not null,
  payout_method public.payment_method not null,
  payout_phone text not null,
  status text not null default 'held',
  provider_reference text unique,
  approved_by uuid references public.profiles(id),
  approved_at timestamptz,
  paid_at timestamptz,
  failure_reason text,
  created_at timestamptz not null default now(),
  constraint payout_amount_check check (amount_htg > 0),
  constraint payout_method_check check (payout_method in ('moncash','natcash')),
  constraint payout_status_check check (status in ('held','review','approved','processing','paid','failed','cancelled'))
);

create index if not exists payouts_status_idx on public.driver_payouts(status, created_at);

-- ---------- TRIP TRACKING, CONSENTS & DISPUTES ----------
create table if not exists public.trip_events (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id) on delete cascade,
  actor_user_id uuid references public.profiles(id),
  event_type public.trip_event_type not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists trip_events_booking_idx on public.trip_events(booking_id, created_at);

create table if not exists public.driver_location_pings (
  id bigserial primary key,
  booking_id uuid not null references public.bookings(id) on delete cascade,
  driver_id uuid not null references public.driver_profiles(user_id),
  latitude double precision not null,
  longitude double precision not null,
  accuracy_meters double precision,
  recorded_at timestamptz not null default now(),
  constraint location_coordinates_check check (latitude between -90 and 90 and longitude between -180 and 180)
);

create index if not exists location_booking_time_idx
  on public.driver_location_pings(booking_id, recorded_at desc);

create table if not exists public.disputes (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id),
  opened_by uuid not null references public.profiles(id),
  reason text not null,
  description text,
  status text not null default 'open',
  resolution text,
  resolved_by uuid references public.profiles(id),
  resolved_at timestamptz,
  created_at timestamptz not null default now(),
  constraint dispute_status_check check (status in ('open','under_review','resolved','rejected'))
);

create table if not exists public.audit_logs (
  id bigserial primary key,
  actor_user_id uuid references public.profiles(id),
  action text not null,
  table_name text not null,
  record_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- ---------- SAFE DRIVER ACCEPTANCE ----------
-- Call this function from a trusted backend (service role), never directly expose
-- service-role credentials in the mobile app. Row lock + unique index ensure one winner.
create or replace function public.accept_booking(
  p_booking_id uuid,
  p_driver_id uuid,
  p_vehicle_id uuid
)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_booking public.bookings%rowtype;
  v_vehicle public.vehicles%rowtype;
begin
  select * into v_booking
  from public.bookings
  where id = p_booking_id
  for update;

  if not found or v_booking.status <> 'paid_unassigned' then
    return false;
  end if;

  select * into v_vehicle
  from public.vehicles
  where id = p_vehicle_id
    and driver_id = p_driver_id
    and is_active = true
    and review_status = 'approved'
    and category = v_booking.vehicle_category;

  if not found then
    return false;
  end if;

  if not exists (
    select 1 from public.driver_profiles
    where user_id = p_driver_id and review_status = 'approved'
  ) then
    return false;
  end if;

  if (v_booking.adults + v_booking.children) > v_vehicle.passenger_capacity
     or v_booking.luggage_count > v_vehicle.luggage_capacity then
    return false;
  end if;

  insert into public.booking_assignments(booking_id, driver_id, vehicle_id)
  values (p_booking_id, p_driver_id, p_vehicle_id);

  update public.bookings
  set status = 'assigned', assigned_at = now(), updated_at = now()
  where id = p_booking_id;

  insert into public.trip_events(booking_id, actor_user_id, event_type)
  values (p_booking_id, p_driver_id, 'driver_assigned');

  return true;
exception when unique_violation then
  return false;
end;
$$;

revoke all on function public.accept_booking(uuid,uuid,uuid) from public, anon, authenticated;
-- Grant execution only to the trusted backend role when deploying on Supabase:
grant execute on function public.accept_booking(uuid,uuid,uuid) to service_role;

-- ---------- BASIC UPDATED-AT TRIGGER ----------
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at before update on public.profiles
for each row execute function public.set_updated_at();

drop trigger if exists bookings_set_updated_at on public.bookings;
create trigger bookings_set_updated_at before update on public.bookings
for each row execute function public.set_updated_at();

-- IMPORTANT SECURITY DEPLOYMENT CHECKLIST:
-- 1. Enable RLS on every public table before connecting a client app.
-- 2. Add policies so customers see only their own bookings/payments;
--    drivers see only eligible dispatch data and their own assignments;
--    admins use a server-side, role-checked dashboard.
-- 3. Store identity/license files in a PRIVATE storage bucket with admin-only access.
-- 4. Do not expose identity_document_number_encrypted or service-role keys to clients.
-- 5. Restrict GPS inserts/reads to an active booking and its assigned parties;
--    stop collecting location when the trip ends.
-- 6. Payment status must be updated only after verifying signed provider webhooks.
-- 7. Keep driver share held until customer confirms completion; after 2 hours without
--    confirmation, set payout to 'review' for admin decision, NOT automatic payout.
-- 8. Configure retention/deletion rules for sensitive identity documents and GPS history.
-- 9. Configure storage, backups, monitoring, provider API credentials and legal terms.
