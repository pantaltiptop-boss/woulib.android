import React, { useMemo, useState } from "react";
import {
  SafeAreaView, ScrollView, View, Text, TextInput, Pressable,
  StyleSheet, Alert, StatusBar
} from "react-native";

const NAVY = "#142B45";
const GOLD = "#F5B942";
const MUTED = "#64748B";
const DESTINATIONS = ["Okay", "Camp-Perrin", "Manich", "Cavaillon", "Lòt destinasyon"];
const CATEGORIES = ["Standard sedan", "Comfort sedan", "SUV", "Van / Minibus"];

function Button({ title, onPress, secondary = false, disabled = false }) {
  return <Pressable disabled={disabled} onPress={onPress}
    style={[styles.button, secondary && styles.secondary, disabled && { opacity: 0.45 }]}>
    <Text style={[styles.buttonText, secondary && { color: NAVY }]}>{title}</Text>
  </Pressable>;
}
function Field({ label, value, onChangeText, placeholder, keyboardType }) {
  return <View style={styles.field}>
    <Text style={styles.label}>{label}</Text>
    <TextInput value={value} onChangeText={onChangeText} placeholder={placeholder}
      placeholderTextColor="#94A3B8" keyboardType={keyboardType}
      style={styles.input} />
  </View>;
}
function Choice({ label, selected, onPress }) {
  return <Pressable onPress={onPress} style={[styles.choice, selected && styles.choiceSelected]}>
    <Text style={[styles.choiceText, selected && { color: NAVY, fontWeight: "700" }]}>{label}</Text>
    <Text style={{ color: selected ? NAVY : MUTED }}>{selected ? "●" : "○"}</Text>
  </Pressable>;
}

export default function App() {
  const [step, setStep] = useState(0);
  const [destination, setDestination] = useState("Camp-Perrin");
  const [customDestination, setCustomDestination] = useState("");
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [flight, setFlight] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [adults, setAdults] = useState("1");
  const [children, setChildren] = useState("0");
  const [bags, setBags] = useState("1");
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState("");
  const [payment, setPayment] = useState("MonCash");
  const [requestCode, setRequestCode] = useState("");

  const finalDestination = destination === "Lòt destinasyon" ? customDestination.trim() : destination;
  const passengerCount = useMemo(() => (Number(adults) || 0) + (Number(children) || 0), [adults, children]);

  function submitDemo() {
    if (!phone.trim() || !date.trim() || !time.trim() || !finalDestination) {
      Alert.alert("Enfòmasyon manke", "Tanpri ranpli destinasyon, dat, lè ak nimewo telefòn.");
      return;
    }
    const code = "WL-DEMO-" + Math.random().toString(36).slice(2, 7).toUpperCase();
    setRequestCode(code);
    setStep(5);
  }

  return <SafeAreaView style={styles.safe}>
    <StatusBar barStyle="light-content" backgroundColor={NAVY} />
    <View style={styles.header}>
      <View style={styles.brandRow}>
        <View style={styles.logo}><Text style={styles.logoText}>W</Text></View>
        <View><Text style={styles.brand}>WOULIB</Text><Text style={styles.tagline}>Rezève. Monte. Rive.</Text></View>
        <View style={styles.demoBadge}><Text style={styles.demoText}>TÈS</Text></View>
      </View>
    </View>
    <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
      {step === 0 && <>
        <Text style={styles.eyebrow}>PLATFÒM TRANSPÒ AYITI</Text>
        <Text style={styles.h1}>Byenvini sou WOULIB</Text>
        <Text style={styles.body}>Rezève transpò ou depi Ayewopò Antoine-Simon, Okay. Chwazi destinasyon ou, bay detay vòl ou, epi resevwa yon òf tarif.</Text>
        <View style={styles.hero}>
          <Text style={styles.heroIcon}>✈</Text>
          <Text style={styles.heroTitle}>Ayewopò Antoine-Simon</Text>
          <Text style={styles.heroSub}>Okay, Ayiti</Text>
        </View>
        <View style={styles.notice}><Text style={styles.noticeText}>Vèsyon demonstrasyon: pa gen peman reyèl, chofè reyèl oswa GPS aktif.</Text></View>
        <Button title="Kòmanse rezèvasyon →" onPress={() => setStep(1)} />
      </>}
      {step === 1 && <>
        <Text style={styles.step}>ETAP 1 SOU 4</Text><Text style={styles.h1}>Ki kote ou prale?</Text>
        <Text style={styles.label}>Kote depa</Text>
        <View style={styles.readonly}><Text style={styles.readonlyText}>✈  Ayewopò Antoine-Simon · Okay</Text></View>
        <Text style={[styles.label, { marginTop: 18 }]}>Destinasyon</Text>
        {DESTINATIONS.map(d => <Choice key={d} label={d} selected={destination === d} onPress={() => setDestination(d)} />)}
        {destination === "Lòt destinasyon" && <Field label="Ekri adrès oswa kote a" value={customDestination} onChangeText={setCustomDestination} placeholder="Egzanp: adrès, zòn, komin..." />}
        <Button title="Kontinye" disabled={!finalDestination} onPress={() => setStep(2)} />
        <Button title="Retounen" secondary onPress={() => setStep(0)} />
      </>}
      {step === 2 && <>
        <Text style={styles.step}>ETAP 2 SOU 4</Text><Text style={styles.h1}>Detay vwayaj la</Text>
        <Field label="Nimewo vòl (si ou genyen)" value={flight} onChangeText={setFlight} placeholder="Egzanp: AA123" />
        <Field label="Dat ou rive" value={date} onChangeText={setDate} placeholder="AAAA-MM-JJ" />
        <Field label="Lè avyon an rive" value={time} onChangeText={setTime} placeholder="Egzanp: 15:30" />
        <Field label="Kantite adilt" value={adults} onChangeText={setAdults} placeholder="1" keyboardType="number-pad" />
        <Field label="Kantite timoun" value={children} onChangeText={setChildren} placeholder="0" keyboardType="number-pad" />
        <Field label="Kantite valiz" value={bags} onChangeText={setBags} placeholder="1" keyboardType="number-pad" />
        <Text style={styles.label}>Kategori machin ou ta prefere</Text>
        {CATEGORIES.map(c => <Choice key={c} label={c} selected={category === c} onPress={() => setCategory(c)} />)}
        <Button title="Kontinye" onPress={() => setStep(3)} />
        <Button title="Retounen" secondary onPress={() => setStep(1)} />
      </>}
      {step === 3 && <>
        <Text style={styles.step}>ETAP 3 SOU 4</Text><Text style={styles.h1}>Kijan nou kontakte ou?</Text>
        <Field label="Nimewo telefòn" value={phone} onChangeText={setPhone} placeholder="+509 ..." keyboardType="phone-pad" />
        <Field label="Lòt enfòmasyon (opsyonèl)" value={notes} onChangeText={setNotes} placeholder="Pwen rankont, bezwen espesyal..." />
        <Text style={styles.label}>Metòd peman ou ta prefere</Text>
        {["MonCash", "NatCash", "Kat Visa / Mastercard"].map(p => <Choice key={p} label={p} selected={payment === p} onPress={() => setPayment(p)} />)}
        <View style={styles.notice}><Text style={styles.noticeText}>Tarif la poko kalkile. Nan sistèm reyèl la, pri a ap parèt an goud anvan ou peye.</Text></View>
        <Button title="Verifye rezèvasyon an" disabled={!phone.trim()} onPress={() => setStep(4)} />
        <Button title="Retounen" secondary onPress={() => setStep(2)} />
      </>}
      {step === 4 && <>
        <Text style={styles.step}>ETAP 4 SOU 4</Text><Text style={styles.h1}>Verifye detay yo</Text>
        <View style={styles.summary}>
          {[["Depa", "Ayewopò Antoine-Simon, Okay"], ["Destinasyon", finalDestination], ["Kategori machin", category], ["Vòl", flight || "Pa antre"], ["Dat / lè", `${date} · ${time}`], ["Pasaje", `${passengerCount} (${adults} adilt, ${children} timoun)`], ["Valiz", bags], ["Telefòn", phone], ["Peman prefere", payment]].map(([k,v]) => <View style={styles.summaryRow} key={k}><Text style={styles.summaryKey}>{k}</Text><Text style={styles.summaryValue}>{v}</Text></View>)}
        </View>
        <Button title="Voye demann tès la" onPress={submitDemo} />
        <Button title="Modifye detay yo" secondary onPress={() => setStep(3)} />
      </>}
      {step === 5 && <>
        <View style={styles.success}><Text style={{ fontSize: 42 }}>✓</Text></View>
        <Text style={styles.h1}>Demann tès la pare!</Text>
        <Text style={styles.body}>Kòd demonstrasyon ou:</Text>
        <Text style={styles.code}>{requestCode}</Text>
        <View style={styles.notice}><Text style={styles.noticeText}>Sa a se yon demonstrasyon lokal. Demann nan pa voye bay chofè ni administratè, epi okenn lajan pa deplase.</Text></View>
        <Button title="Fè yon lòt rezèvasyon" onPress={() => { setRequestCode(""); setStep(0); }} />
      </>}
      <Text style={styles.footer}>WOULIB · Ayiti · Premye vèsyon demonstrasyon</Text>
    </ScrollView>
  </SafeAreaView>;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#F5F7FA" },
  header: { backgroundColor: NAVY, paddingHorizontal: 20, paddingVertical: 16 },
  brandRow: { flexDirection: "row", alignItems: "center", gap: 11 },
  logo: { width: 42, height: 42, borderRadius: 12, backgroundColor: GOLD, alignItems: "center", justifyContent: "center" },
  logoText: { color: NAVY, fontWeight: "900", fontSize: 25 },
  brand: { color: "white", fontWeight: "900", fontSize: 21, letterSpacing: 2 },
  tagline: { color: "#D8E1EC", fontSize: 11, marginTop: 1 },
  demoBadge: { marginLeft: "auto", borderColor: GOLD, borderWidth: 1, borderRadius: 6, paddingHorizontal: 9, paddingVertical: 5 },
  demoText: { color: GOLD, fontSize: 10, fontWeight: "800" },
  content: { padding: 20, paddingBottom: 40 },
  eyebrow: { color: "#B27A12", fontSize: 11, fontWeight: "800", letterSpacing: 1.5, marginTop: 10 },
  h1: { color: NAVY, fontSize: 27, fontWeight: "900", marginTop: 8, marginBottom: 12 },
  body: { color: "#475569", fontSize: 15, lineHeight: 23, marginBottom: 18 },
  hero: { backgroundColor: NAVY, borderRadius: 18, padding: 25, alignItems: "center", marginVertical: 10 },
  heroIcon: { fontSize: 42, color: GOLD, marginBottom: 12 },
  heroTitle: { color: "white", fontSize: 18, fontWeight: "800" },
  heroSub: { color: "#CBD5E1", marginTop: 5 },
  notice: { backgroundColor: "#FFF4D8", borderColor: "#F2D38B", borderWidth: 1, borderRadius: 12, padding: 13, marginVertical: 14 },
  noticeText: { color: "#76520B", fontSize: 12, lineHeight: 18 },
  button: { backgroundColor: NAVY, borderRadius: 12, padding: 16, alignItems: "center", marginTop: 12 },
  buttonText: { color: "white", fontWeight: "800", fontSize: 15 },
  secondary: { backgroundColor: "#E8EDF3", borderWidth: 1, borderColor: "#D3DCE7" },
  step: { color: "#B27A12", fontSize: 11, fontWeight: "900", letterSpacing: 1.2, marginTop: 8 },
  label: { color: NAVY, fontWeight: "700", fontSize: 13, marginBottom: 7, marginTop: 10 },
  field: { marginTop: 9 },
  input: { backgroundColor: "white", borderWidth: 1, borderColor: "#D7DFE8", borderRadius: 10, paddingHorizontal: 13, paddingVertical: 13, fontSize: 15, color: NAVY },
  choice: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", backgroundColor: "white", borderWidth: 1, borderColor: "#D7DFE8", borderRadius: 10, padding: 14, marginTop: 8 },
  choiceSelected: { borderColor: GOLD, backgroundColor: "#FFF9EA" },
  choiceText: { color: "#334155", fontSize: 14 },
  readonly: { backgroundColor: "#E8EDF3", borderRadius: 10, padding: 14 },
  readonlyText: { color: NAVY, fontWeight: "700" },
  summary: { backgroundColor: "white", borderRadius: 14, padding: 14, borderWidth: 1, borderColor: "#E0E6ED" },
  summaryRow: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 9, borderBottomWidth: 1, borderBottomColor: "#EEF1F5", gap: 12 },
  summaryKey: { color: MUTED, fontSize: 12, flex: 1 },
  summaryValue: { color: NAVY, fontSize: 12, fontWeight: "700", flex: 1.5, textAlign: "right" },
  success: { width: 74, height: 74, borderRadius: 37, backgroundColor: "#DDF5E6", alignItems: "center", justifyContent: "center", alignSelf: "center", marginTop: 28, marginBottom: 12 },
  code: { color: NAVY, fontSize: 22, fontWeight: "900", letterSpacing: 2, textAlign: "center", marginVertical: 12 },
  footer: { textAlign: "center", color: "#94A3B8", fontSize: 10, marginTop: 30 }
});
