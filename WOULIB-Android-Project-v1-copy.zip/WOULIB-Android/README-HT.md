# WOULIB — Premye pwojè aplikasyon Android/iOS

## Sa vèsyon sa a ye
- Aplikasyon kliyan React Native + Expo.
- Premye koule rezèvasyon pou Ayewopò Antoine-Simon, Okay.
- Destinasyon, kategori machin, detay vòl, dat/lè, pasaje, valiz, telefòn ak metòd peman prefere.
- Kòd demonstrasyon lokal sèlman: pa gen demann reyèl ki ale nan sèvè.

## Sa li poko fè
Li poko konekte ak backend, aplikasyon chofè, panèl admin, GPS, tarif reyèl, MonCash/NatCash API, peman kat, oswa peman chofè. Pa itilize li pou opere sèvis taksi oswa kolekte lajan. SQL ki nan pwojè a se yon premye modèl baz done; li bezwen RLS/policies, revizyon sekirite, tès ak migrasyon anvan koneksyon.

## Konfigirasyon aktyèl
- Expo SDK 58
- React 19.3.0
- React Native 0.88.1
- Android package: `com.woulib.app`
- Preview build: APK pou enstale dirèkteman
- Production build: AAB pou Google Play

## Kijan pou jwenn APK la san laptop (telefòn Android sèlman)
Nou ka sèvi ak GitHub Actions + Expo EAS cloud build. Sa mande kont gratis GitHub ak kont Expo. Pa voye modpas oswa token bay pèsonn.

1. Kreye / konekte nan kont Expo sou `https://expo.dev/`.
2. Kreye yon access token nan kont Expo ou (account settings / access tokens). Kenbe l prive.
3. Kreye yon nouvo repository prive sou `https://github.com/`.
4. Mete tout fichye pwojè sa a nan repository a, ak menm estrikti dosye yo.
5. Nan GitHub repository a, ale nan **Settings → Secrets and variables → Actions → New repository secret**.
6. Ajoute secret `EXPO_TOKEN` ak access token Expo ou. Ajoute yon lòt secret `EXPO_ACCOUNT` ki se non kont Expo ou (account slug). Kenbe toude prive; pa mete yo nan kòd la ni voye yo nan chat.
7. Ale nan **Actions → WOULIB Android preview APK → Run workflow** (oswa pouse commit sou branch `main`). Workflow la pral kreye/konekte pwojè EAS la epi lanse build APK la.
8. Si workflow la echwe, ouvri log la nan GitHub Actions. Erè a ka soti nan token, non kont Expo, oswa konfigirasyon EAS; pa peye anyen pou sa.
9. Lè EAS fini, ouvri build la nan `https://expo.dev/`, telechaje APK la sou telefòn Android ou, epi enstale li. Android ka mande otorizasyon pou enstale aplikasyon ki soti nan navigatè a.

Workflow GitHub la lanse yon build APK nan nwaj Expo. Li pa garanti build la ap reyisi san premye konfigirasyon EAS account/project la.

## Google Play pita
Pou Google Play, n ap bezwen:
- Kont Play Console (18+; frè enskripsyon yon sèl fwa US$25, dapre Google).
- Privacy policy ak Data safety deklarasyon ki koresponn ak sa app la vrèman kolekte.
- App icon, screenshots, deskripsyon ak kontak sipò.
- AAB production ki siyen.
- Internal testing release ak verifikasyon Play Console.

Nou pa bezwen peye Play Console pou fè premye APK preview la.

## Sekirite
Pa mete modpas, EXPO_TOKEN, Supabase service-role key, MonCash/NatCash secret oswa kle bank nan app mobil lan ni nan fichye piblik. Sekrè yo dwe rete nan GitHub Secrets/EAS secrets oswa backend ki pwoteje.
